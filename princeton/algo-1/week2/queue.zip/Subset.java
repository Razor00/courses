import java.util.Iterator;
public class Subset {
    public static void main(String[] args)
    {
        int j, k;
        int count;
        RandomizedQueue<String> rdq = new RandomizedQueue<String>();
        k = Integer.parseInt(args[0]);

        count = 0;
        while (count < k && !StdIn.isEmpty()) {
            String item = StdIn.readString();
            count++;
            rdq.enque(item);
        }
        while (!StdIn.isEmpty()) {
            String item = StdIn.readString();
            j = StdRandom.uniform(1, count+1);
            if (j <= k) {
                rdq.deque();
                rdq.enque(item);
            }
        }
        Iterator itr = rdq.iterator();
        while (itr.hasNext()) {
            StdOut.println(itr.next());
        }
    }
}
